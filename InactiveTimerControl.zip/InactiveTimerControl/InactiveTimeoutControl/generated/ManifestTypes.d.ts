/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    SessionTimeOutDuration: ComponentFramework.PropertyTypes.WholeNumberProperty;
    SessionStatus: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    SessionStatus?: string;
}
